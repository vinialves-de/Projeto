﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PapoReto.View
{
    public partial class FrmPrincipal : Form
    {
        private Form frmAtivo;

        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void FormShow(Form frm)
        {
            ActiveFormClose();
            frmAtivo = frm;
            frm.TopLevel = false;
            panelForm.Controls.Add(frm);
            frm.BringToFront();
            frm.Show();
        }

        private void ActiveFormClose()
        {
            if (frmAtivo != null)
                frmAtivo.Close();
        }
        private void ActiveButton(Button frmAtivo)
        {
            foreach (Control ctrl in panelPrinicipal.Controls)
                ctrl.ForeColor = Color.White;
            frmAtivo.ForeColor = Color.Red;
        }



        private void panelLogo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void panelForm_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            ActiveButton(btnHome);
            ActiveFormClose();
        }

       
        private void btnCadastro_Click_1(object sender, EventArgs e)
        {
            ActiveButton(btnCadastro);
            FormShow(new FrmCadastro());
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void btnComunidade_Click(object sender, EventArgs e)
        {
            ActiveButton(btnCadastro);
            FormShow(new ChatApp());
        }
    }
}
