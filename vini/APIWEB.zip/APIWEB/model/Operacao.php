<?php

class Operacao{

    private $con;

    function __construct()
    {
        require_once dirname(__FILE__).'./Conexao.php';
        
        $bd = new Conexao();

        $this->con = $bd->connect();
    }

    function createUsu($campo_2,$campo_3,$campo_4){
      $stmt = $this->con->prepare("INSERT INTO cadastrousu(nomeUsu,emailUsu,senhaUsu) VALUES (?,?,?)");   
      $stmt->bind_param("sss",$campo_2,$campo_3,$campo_4);
        if($stmt->execute())
            return true;
        return var_dump($stmt);
    }
    
    function getUsu(){
        $stmt = $this->con->prepare("Select * from cadastrousu");
        $stmt->execute();
        $stmt->bind_result($codigousu,$nomeusu,$emailusu,$senhausu);

        $dicas = array();

        while($stmt->fetch()){
            $dica = array();
            $dica['codUsu']= $codigousu;
            $dica['nomeUsu'] = $nomeusu;
            $dica['emailUsu'] = $emailusu;
            $dica['senhaUsu'] = $senhausu;
            array_push($dicas,$dica);
        }
        return $dicas;
    }

}