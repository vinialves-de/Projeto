<!doctype html>
<html lang="PT-BR">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link href="../css/estilo.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    

    <title>Home Page Bootstrap</title>
 
  </head>
  <body>
  <!--Garantindo os campos preenchidos-->
    <?php
session_start();
$email = isset($_SESSION["emailUsu"])?$_SESSION["emailUsu"]:null;
if($email != null){
include("../Model/conexao.php");
include("../Model/bancoUsuarios.php");
}
?>       

      <!--MENU -->
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php"><img src="../imagens/logo-app.png" width="100"></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
              <a class="nav-link" aria-current="page" href="entrar.php">ENTRAR</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="cadastrar.php">CADASTRAR</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="quemsomos.php"> QUEM SOMOS </a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link" href="contato.php" tabindex="-1" aria-disabled="true">CONTATO</a>
              </li>
            </ul>
           
          </div>
        </div>
      </nav>
     
      <!--Conteúdo-->
    <div class="conteudo">
      <br>

    <div class="formulario">
    <form method="POST" action="../Controller/inserirUsuarios.php">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Nome</label>
                    <input type="text" class="form-control" name="nome" id="nomee" aria-describedby="emailHelp">
                    <div id="" class="form-text">As informações acima não serão compartilhadas com terceiros.</div>
                  </div>
                <div class="mb-3">
                  <label for="exampleInputEmail1" class="form-label">Email</label>
                  <input type="email" name="email"class="form-control" id="emaill" aria-describedby="emailHelp">
                  <div id="emaill" class="form-text">As informações acima não serão compartilhadas com terceiros.</div>
                </div>
                <div class="mb-3">
                  <label for="exampleInputPassword1" class="form-label">Senha</label>
                  <input type="password" name="senha" class="form-control" id="senhaa">
                </div>
             
                <button type="submit" class="btn btn-dark">Enviar </button>
                <a type="button"  class="btn btn-dark" href="entrar.php">Já tenho conta</a>
                <a type="button"   class="btn btn-dark" href="index.php">Voltar</a>
              </form>
</div>
  </div>
</div>
</div>

 
    <footer class="footerC">
     
    <div class="redes">
          <a href="https://github.com/">
            <a href="https://www.facebook.com/" class="fa fa-facebook"  style="text-decoration:none"></a>
            <a href="https://twitter.com/home" class="fa fa-twitter"  style="text-decoration:none"></a>
            <a href="https://www.instagram.com/" class="fa fa-instagram"  style="text-decoration:none"></a>
            <p> <a href="termos.php"  style="text-decoration:none">Termos de serviço</a> </p>
      </div>
    </div>
    </footer>
   

    
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
  </body>
</html>