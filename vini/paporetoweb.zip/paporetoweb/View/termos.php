<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link href="../css/estilo.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    

    <title>Termos de serviço</title>
  </head>
  <body>
    <!-- Verifica se existe os dados da sessão de login  -->
  <?php
//include_once("../Controller/verificar.php");
?>

      <!--MENU -->
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php"><img src="../imagens/logo-app.png" width="100"></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="entrar.php">ENTRAR</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="cadastrar.php">CADASTRAR</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="quemsomos.php"> QUEM SOMOS </a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link" href="contato.php" tabindex="-1" aria-disabled="true" >CONTATO</a>
              </li>
            </ul>
           
          </div>
        </div>
      </nav>
     
      <!--Conteúdo-->
    <div class="conteudo">
    
    

            <h1>Termos de serviço </h1>
            <div class="letraT">
            <p>
              <p>Data de vigência: 08 de abril de 2022</p>

              <p>POR FAVOR, NOTE QUE A UTILIZAÇÃO E ACESSO DOS NOSSOS SERVIÇOS (DEFINIDOS ABAIXO) ESTÃO SUJEITOS AOS TERMOS A SEGUIR; SE NÃO CONCORDAR COM ELES, VOCÊ NÃO PODERÁ UTILIZAR OU ACESSAR OS SERVIÇOS DE FORMA ALGUMA.</p>
              
              <p>ESTES TERMOS A SEGUIR CONTÉM UMA EXIGÊNCIA DE ARBITRAGEM OBRIGATÓRIA E UMA RENÚNCIA DE AÇÃO COLETIVA QUE AFETAM OS SEUS DIREITOS LEGAIS DE RESOLVER LITÍGIOS, A MENOS QUE OPTE POR REJEITAR. POR FAVOR, LEIA COM ATENÇÃO.</p>
              
              Bem-vindo(a) ao PapoReto App. Por favor, leia as regras e restrições que governam o uso de nossos aplicativos (os "Serviços"). Se você tiver alguma dúvida, comentários, preocupações sobre esses termos ou os de Serviço, entre em contato conosco por meio do nosso formulário de suporte.
              
              Esses Termos de Serviço (os "Termos") são um contrato vinculativo entre você e o PapoReto App, ("PapoReto", “nós"), o proprietário do PapoReto App. Você deve concordar e aceitar todos os Termos, ou não tem o direito de usar os Serviços. Ao usar os Serviços de qualquer modo, você concorda com estes Termos, e eles permanecerão em vigor enquanto usa os Serviços. Estes Termos incluem as disposições deste documento, bem como as de Política de Privacidade.
             
            </p>
          </div>
          
  
              

  
 
    <footer class="footerT">
     
    <div class="redes">
          <a href="https://github.com/">
            <a href="https://www.facebook.com/" class="fa fa-facebook"  style="text-decoration:none"></a>
            <a href="https://twitter.com/home" class="fa fa-twitter"  style="text-decoration:none"></a>
            <a href="https://www.instagram.com/" class="fa fa-instagram"  style="text-decoration:none"></a>
            <p> <a href="termos.php"  style="text-decoration:none">Termos de serviço</a> </p>
      </div>
    </div>
    </footer>
   

    
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
  </body>
</html>