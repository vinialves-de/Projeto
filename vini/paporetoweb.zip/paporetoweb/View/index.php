<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link href="../css/estilo.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <title>Conheça o PapoReto</title>
  </head>
  <body>
  <!-- Verifica se existe os dados da sessão de login  -->
<?php

//include_once("../Controller/verificar.php");
?>

      <!--MENU -->
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php"><img src="../imagens/logo-app.png" width="100"></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="entrar.php">ENTRAR</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="cadastrar.php">CADASTRAR</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="quemsomos.php"> QUEM SOMOS </a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link" href="contato.php" tabindex="-1" aria-disabled="true">CONTATO</a>
              </li>
            </ul>
           
          </div>
        </div>
      </nav>

     <!-- Carousel-->
      <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="../imagens/banner1.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>BIG DATA | DEVOPS</h5>
              <p>Tratamento dos seus dados com tecnologias ágeis</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="../imagens/banner2.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>PALESTRAS | TREINAMENTOS</h5>
              <p>Contamos com uma equipe especializada para atendê-lo.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="../imagens/banner3.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h5>DEV | CLOUD | ANALYTICS</h5>
              <p>Some representative placeholder content for the third slide.</p>
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>

      <!--Conteúdo-->
    <div class="conteudo">

      <h2>PapoReto</h2>  
            
      <p>
        Fale sobre o que quiser e quando quiser
      </p>
     
      <div class="d-flex justify-content-center">
      <div class="row">
        <div class="col-md-5">
          <h4>
            TENHA OS ASSUNTOS EM DIA
          </h4>
          <p>
            
            Saiba o que está rolando ao redor do mundo, em todos os campos...esporte,dança,anime,música,filme,desenho,série...
          </p>
          
        </div>
        <div class="col-md-7">
          <h4>
           TENHA UM CHAT PARTICULAR
          </h4>
          <p>
            Tenha um chat particular e converse com seu amigo.
A área de "Categorias" permite que voce crie ou entre em comunidades, faça amizades e converse sobre seu assunto favorito.

          </p>
          
        </div>
        <div class="novidades">
<br>
<h4>Novidades</p></h4>
<p>dkshsdsassajdashdiuahfuishdsjfdhfasjdijudi9sadjjjjjjjjjjjjjpasdjpioasjdpsadasdajdisajdpadasdjan</p>
<li>nskndkadsnkpd</li>
<li>nskndkadsnkpd</li>
<li>nskndkadsnkpd</li>



</div>
      </div>
    </div>
  </div>

  <!-- Cards -->
  <div class="d-flex justify-content-center">
    <div class="card" style="width: 10rem;">
      <img src="../imagens/play.png" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Disponível na PlayStore</h5>
        
        <a href="https://play.google.com" class="btn btn-dark">Baixar</a>
      </div>
    </div>

    <div class="card" style="width: 10rem;">
    
    <img src="../imagens/appstore.png" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Disponível na AppleStore</h5>
        
        <a href="https://www.apple.com" class="btn btn-dark">Baixar</a>
      </div>
    </div>

    
    </div>

 
    <footer>
     
        <div class="redes">
          <a href="https://github.com/">
            <a href="https://www.facebook.com/" class="fa fa-facebook"  style="text-decoration:none"></a>
            <a href="https://twitter.com/home" class="fa fa-twitter"  style="text-decoration:none"></a>
            <a href="https://www.instagram.com/" class="fa fa-instagram"  style="text-decoration:none"></a>
            <p> <a href="termos.php"  style="text-decoration:none">Termos de serviço</a> </p>
      </div>
    </div>
    </footer>
   

    
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
  </body>
</html>