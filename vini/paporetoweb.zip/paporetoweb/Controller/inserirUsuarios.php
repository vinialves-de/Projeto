<?php
include("../Model/conexao.php");
include("../Model/bancoUsuarios.php");

  //Forçando o usuário a preencher os dados
extract($_REQUEST,EXTR_OVERWRITE);
if($nome == ""){
    echo '<script> alert("Preencha todos os campos"); location.href=("../View/cadastrar.php") </script>';

}elseif($email == ""){
    echo '<script> alert("Preencha todos os campos"); location.href=("../View/cadastrar.php") </script>';
}elseif($senha == ""){
    echo '<script> alert("Preencha todos os campos"); location.href=("../View/cadastrar.php") </script>';
}else{

    //Cadastrando o usuário no banco através da função "acessoEntrar"
if(inserirUsuarios($conexao,$nome,$email,$senha)){
    echo '<script> alert("Perfil cadastrado com sucesso"); location.href=("../View/cadastrar.php") </script>';
  
   
}
else{
    echo("Algo deu errado");
 }
}

 
?>