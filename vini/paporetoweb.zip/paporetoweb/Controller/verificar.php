<?php
include("../Model/conexao.php");
include("../Model/bancoUsuarios.php");

session_start();

// Verifica se existe os dados da sessão de login
if(!isset($_SESSION["nomeUsu"]) || !isset($_SESSION["emailUsu"]) || !isset($_SESSION["senhaUsu"]))
{
// Usuário não logado, Redireciona para a página de login
header("Location: entrar.php");
exit;
}

?>

