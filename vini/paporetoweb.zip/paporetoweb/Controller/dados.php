<<?php
session_start();
include_once("../Model/bancoUsuarios.php");
include_once("../Model/conexao.php");



$email =$_POST["email"]; 
$senha =$_POST["senha"];  
$acesso = acessoEntrar($conexao,$email,$senha);

//Forçando usuário a preencher os dados e verificando se os dados estão corretos de acordo com o banco de dados
if($email == ""){
    echo '<script> alert("Preencha todos os campos"); location.href=("../View/entrar.php") </script>';

}elseif($senha == ""){
    echo '<script> alert("Preencha todos os campos"); location.href=("../View/entrar.php") </script>';
}else {
if($email === $acesso){
    header("Location:../View/index.php");
}else{
    echo '<script> alert("Dados incorretos"); location.href=("../View/entrar.php") </script>';
}
}

?>