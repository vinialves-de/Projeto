<?php
$url ='localhost';
$usuario ='root';
$senha = '';
$nomeBanco ='bdpaporeto' ;
//Conectando com o banco de dados
$conexao = mysqli_connect($url,$usuario,$senha,$nomeBanco);
?>