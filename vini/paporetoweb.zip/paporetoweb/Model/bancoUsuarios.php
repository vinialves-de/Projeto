<?php
//Função que insere os dados do usuário no banco de dados
function inserirUsuarios($conexao,$nome,$email,$senha){

    $option = ['cost =>8'];
    $senha = password_hash($senha,PASSWORD_BCRYPT,$option);
    $query = "insert into cadastrousu(nomeUsu,emailUsu,senhaUsu)values('{$nome}','{$email}','{$senha}')";

    $resultados = mysqli_query($conexao,$query);
    return $resultados;

    
}
//Função que permite o acesso do usuário no site
function acessoEntrar($conexao,$email,$senha){
        $query = "select * from cadastrousu where emailUsu='{$email}'";

        $resultados = mysqli_query($conexao,$query);

        if(mysqli_num_rows($resultados) > 0){
            $linha = mysqli_fetch_assoc($resultados);
            
            if(password_verify($senha,$linha['senhaUsu'])){
                $_SESSION["emailUsu"] = $linha["emailUsu"];
                $_SESSION["codigoUsu"] = $linha['codigoUsu'];

                return $linha["emailUsu"];
                
            }else{
                return "Senha não confere";
            }
        }
   
    
}
?>