<?php

require_once '../model/Operacao.php';

function isTheseParametersAvailable($params){
$avalilable = true;
$missingparams = "";

foreach($params as $param){
    if(!isset($_POST[$param]) || strlen($_POST[$param])<=0){
        $avalilable = false;
        $missingparams = $missingparams.", ".$param;
    }
}

if(!$avalilable){
    $response = array();
    $response['error'] = true;
    $response['message'] = 'Parameters '.substr($missingparams, 1,strlen($missingparams)).' missing';

    echo json_encode($response);

    die();
}
}

$response = array();

if(isset($_GET['apicall'])){
    switch($_GET['apicall']){

        case 'createUsu':
           isTheseParametersAvailable(array('campo_2','campo_3','campo_4','campo_5','campo_6'));

            $db = new Operacao();

            $result = $db->createUsu(
                $_POST['campo_2'],
                $_POST['campo_3'],
                $_POST['campo_4'],
                $_POST['campo_5'],
                $_POST['campo_6']
               
            );

            if($result){
                $response['error'] = false;
                $response['message']= 'Dados inseridos com sucesso.';
                $response['dadoscreate'] = $db->getUsu();
            }else{
                $response['error'] = true;
                $response['message']= 'Dados nao foram inseridos.';
            }

        break;
        case 'getUsu':
            $db= new Operacao();
            $response['error'] = false;
            $response['message']= 'Dados Listados com sucesso.';
            $response['dadoslista']=$db->getUsu();

        break;
        
        case 'createCat':
            isTheseParametersAvailable(array('campo_2','campo_3','campo_4'));
 
             $db = new Operacao();
 
             $result = $db->createCat(
                 $_POST['campo_2'],
                 $_POST['campo_3'],
                 $_POST['campo_4']
               
             );
 
             if($result){
                 $response['error'] = false;
                 $response['message']= 'Dados inseridos com sucesso.';
                 $response['dadoscreate'] = $db->getCat();
             }else{
                 $response['error'] = true;
                 $response['message']= 'Dados nao foram inseridos.';
             }
 
         break;

         case 'getCat':
            $db= new Operacao();
            $response['error'] = false;
            $response['message']= 'Dados Listados com sucesso.';
            $response['dadoslista']=$db->getCat();

        break;

        case 'createSalaCat':
            isTheseParametersAvailable(array('campo_2','campo_3','campo_4'));
 
             $db = new Operacao();
 
             $result = $db->createSalaCat(
                 $_POST['campo_2'],
                 $_POST['campo_3'],
                 $_POST['campo_4']
               
             );
 
             if($result){
                 $response['error'] = false;
                 $response['message']= 'Dados inseridos com sucesso.';
                 $response['dadoscreate'] = $db->getSalaCat();
             }else{
                 $response['error'] = true;
                 $response['message']= 'Dados nao foram inseridos.';
             }
 
         break;

         case 'getSalaCat':
            $db= new Operacao();
            $response['error'] = false;
            $response['message']= 'Dados Listados com sucesso.';
            $response['dadoslista']=$db->getSalaCat();

        break;
         }
    }else{
        $response['error'] = true;
        $response['message'] = "Chamada sw Api com defeito";
    }


echo json_encode($response);