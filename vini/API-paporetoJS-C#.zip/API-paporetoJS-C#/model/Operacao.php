<?php

class Operacao{

    private $con;

    function __construct()
    {
        require_once dirname(__FILE__).'./Conexao.php';
        
        $bd = new Conexao();

        $this->con = $bd->connect();
    }

    function createUsu($campo_2,$campo_3,$campo_4,$campo_5,$campo_6){
      $stmt = $this->con->prepare("INSERT INTO tbusuario (nomeusu,emailusu,senhausu,foneusu,fotousu) VALUES (?,?,?,?,?)");   
      $stmt->bind_param("sssss",$campo_2,$campo_3,$campo_4,$campo_5,$campo_6);
        if($stmt->execute())
            return true;
        return var_dump($stmt);
    }
    function createCat($campo_2,$campo_3,$campo_4){
        $stmt = $this->con->prepare("INSERT INTO tbcategoria (titulocat,descricaocat,temaca,foneusu,fotousu) VALUES (?,?,?,?,?)");   
        $stmt->bind_param("sssss",$campo_2,$campo_3,$campo_4);
          if($stmt->execute())
              return true;
          return var_dump($stmt);
      }

      function createSalaCat($campo_2,$campo_3,$campo_4){
        $stmt = $this->con->prepare("INSERT INTO tbsalacategoria (idusuFK,comentariosalaCat,idcatFK) VALUES (?,?,?)");   
        $stmt->bind_param("isi",$campo_2,$campo_3,$campo_4);
          if($stmt->execute())
              return true;
          return var_dump($stmt);
      }
      


    function getUsu(){
        $stmt = $this->con->prepare("Select * from tbusuario");
        $stmt->execute();
        $stmt->bind_result($uid,$nomeusu,$emailusu,$senhausu,$foneusu,$fotousu);

        $dicas = array();

        while($stmt->fetch()){
            $dica = array();
            $dica['uid']= $uid;
            $dica['nomeusu'] = $nomeusu;
            $dica['emailusu'] = $emailusu;
            $dica['senhausu'] = $senhausu;
            $dica['foneusu'] = $foneusu;
            $dica['fotousu'] = $fotousu;
            array_push($dicas,$dica);
        }
        return $dicas;
    }

    function getCat(){
        $stmt = $this->con->prepare("Select * from tbcategoria");
        $stmt->execute();
        $stmt->bind_result($uid,$titulocat,$temacat,$descricaocat);

        $dicas = array();

        while($stmt->fetch()){
            $dica = array();
            $dica['uid']= $uid;
            $dica['titulocat'] = $titulocat;
            $dica['temacat'] = $temacat;
            $dica['descricaocat'] = $descricaocat;
            array_push($dicas,$dica);
        }
        return $dicas;
    }
    function getSalaCat(){
        $stmt = $this->con->prepare("Select * from tbsalacategoria");
        $stmt->execute();
        $stmt->bind_result($uid,$idsalaCat,$idusuFK,$idcatFK,$comentariosalaCat);

        $dicas = array();

        while($stmt->fetch()){
            $dica = array();
            $dica['idsalaCat']= $uid;
            $dica['idusuFK'] = $idusuFK;
            $dica['idcatFK'] = $idcatFK;
            $dica['comentariosalaCat'] = $comentariosalaCat;
            array_push($dicas,$dica);
        }
        return $dicas;
    }


    
}