-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 20-Jun-2022 às 02:27
-- Versão do servidor: 10.4.19-MariaDB
-- versão do PHP: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `bdpaporeto`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastrousu`
--

CREATE TABLE `cadastrousu` (
  `codigoUsu` int(10) NOT NULL,
  `nomeUsu` varchar(40) NOT NULL,
  `emailUsu` varchar(40) NOT NULL,
  `senhaUsu` char(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `cadastrousu`
--

INSERT INTO `cadastrousu` (`codigoUsu`, `nomeUsu`, `emailUsu`, `senhaUsu`) VALUES
(1, '', '', ''),
(2, '', '', ''),
(3, '', '', ''),
(4, '', '', ''),
(5, '', '', ''),
(6, '', '', ''),
(7, '', '', ''),
(8, '', '', ''),
(9, '', '', ''),
(10, '', '', ''),
(11, '', '', ''),
(12, '', '', ''),
(13, '', '', ''),
(14, '', '', ''),
(15, '', '', '$2y$10$gmablvSHVBzz0ZgY.YpyHOcXbfnyu8foaA6qEGAdecJPVakDzkP8m'),
(16, '', '', '$2y$10$wvnXKIOc2nHShTPqdwsfnOE1Qpxq5Gi/qwPQ/v.XStpmS2tnVKC9O'),
(17, '', '', ''),
(18, '', '', ''),
(19, '', '', ''),
(20, '', '', ''),
(21, '', '', ''),
(22, '', '', ''),
(23, '', '', ''),
(24, '', '', '$2y$10$ryrwIkqBNWQxiAUULy9aJOKJbeTnx9WsDpBZVJhsVcZhE/jPG2gvS'),
(25, '', '', '$2y$10$.TwMBP2FxYGSIbXI7rXMKew/WKH8Ikh8jIh85H8JAW7oGfqBEkrhm');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `cadastrousu`
--
ALTER TABLE `cadastrousu`
  ADD PRIMARY KEY (`codigoUsu`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cadastrousu`
--
ALTER TABLE `cadastrousu`
  MODIFY `codigoUsu` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
